<?php
 include("../include/connection.php");

class Faculty 

{
public $faculty_id;
public $name;
public $email;
public $dept_name;
public $photo;
public $phone_no;
public $user_details;
public $conn;
public $fname;

public function getinfo()
    {  
        include("../include/connection.php");
        $this->faculty_id='12345';
        $sql= "select * from faculty_details where fid='12345'";
        $result=$conn->query( $sql );
        while($row = $result->fetch_assoc())
        {
        $this->user_details[]=$row;
        }
        return $this->user_details;
    }

public function viewfeedback()
    {
        include("../include/connection.php");
        $sql = "select name,deptname from faculty_details where fid='12345'";
        $result = $conn->query($sql);
        while($row = $result-> fetch_assoc())
        {
            $this->user_details[]=$row;

        }
        return $this->user_details;
    }
}

//     public function rolllist()
//     {
//         include ("../include/connection.php");
//         $sql= "select distinct(classid) from subject_allocation where fid='$st'";
//             $c = $conn->query($sql);
//             while($res=$c->fetch_array())
//             {
//                 $res1="select *from class_details where classid='$res[classid]' and active='YES'";
//                 $res1=$conn->query($res1);
//                 <option value="<?php echo $rs['classid'].",".$rs['courseid'].",S".$rs['semid'].",".$rs['branch_or_specialisation'];?>">
//                 
//             }
<!-- // //     }
// }
// public function seriesmark()
// {
//     include("../include/connection.php");
//         $sql = "select name,deptname from faculty_details where fid='12345'";
//         $result = $conn->query($sql);
//         while($row = $result-> fetch_assoc())
//         {
//             $this->user_details[]=$row;

//         }
//         return $this->user_details;
//     } -->


?>