<?php

include("../include/connection.php");

$tool_id = $_GET['tool_id'];

        $del = mysqli_query($conn,"delete from accreditation_assesment_tool where tool_id='$tool_id'");

        if( $del )
            {
                echo "<script> alert('Successfully Deleted')</script>";
                echo "<script>window.location.href='view_assesment_tool.php'</script>";
            }
        else{
            echo "<script> alert('Error!Try Again')</script>";
            echo "<script>window.location.href='view_assesment_tool.php'</script>";
        }

?>