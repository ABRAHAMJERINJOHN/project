<?php
//session_start();
//$con=mysqli_connect("localhost","root","","ritsoft3");
include("../include/connection.php"); 
include("../include/report_errors.php");

//$username=$_SESSION['fid'];
$username=12345;
$sub_id=$_REQUEST['id'];

?>
<script>
alert("<?php echo $sub_id;?>");
</script>
<select name="assessment_tool" id="assessment_tool" class="form-control" onchange="btn_active();">
<option>select</option>
<?php
$c=$conn->query("select * from  accreditation_assesment_tool where subjectid='$sub_id'");
while($re=$c->fetch_array())
{

?>
<option value="<?php echo $re['tool_id'];?>"><?php  echo $re['name'];?></option>
<!--<option value="<?php //$subt=$re['subjectid']; echo $re['subjectid'];?>"><?php  //echo $re['subject_title'];?></option>-->
<?php
}
?>
</select>