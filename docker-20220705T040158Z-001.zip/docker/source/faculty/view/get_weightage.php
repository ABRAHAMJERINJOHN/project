<?php
//session_start();
//$con=mysqli_connect("localhost","root","","ritsoft3");
include("../include/connection.php"); 
//$username=$_SESSION['fid'];
$username=12345;
$subject_id=explode("-",$_REQUEST['id']);
$category_type=$_REQUEST['category_type'];
$total_weightage = 0;
if($category_type == 'direct'){
    $get_assess_tool_cat = $conn->query("select ass_category_id from accreditation_assessment_tool_category where category_type ='direct'");
    while($res_assess_tool_cat=mysqli_fetch_array($get_assess_tool_cat)){
        // echo 'cat id is '.$res_assess_tool_cat[0];
        // echo 'subject id is '.$subject_id[0];
        $sql = $conn->query("select weightage from accreditation_assesment_tool where subjectid ='$subject_id[0]' and category_id='$res_assess_tool_cat[0]'");
        while($result=mysqli_fetch_array($sql))
        {
            // echo 'weightage is '.$result[0];
            $total_weightage = $total_weightage+$result[0];
            // echo 'total weightage is '.$total_weightage;
        }
    }
    $balance_weightage = 80 - $total_weightage;
    echo $balance_weightage;
}
elseif($category_type == 'indirect'){
    $balance_weightage = 20;
    echo $balance_weightage;
}

?>
