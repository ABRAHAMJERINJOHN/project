<?php
include("../include/connection.php");
require_once("dompdf/autoload.inc.php");
include("../include/report_errors.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$class=$_GET['class'];


$html=""; 
$html.='<html>';
$html.='<head>';

$html.='</head>';
$html.='<body>';               
$html .= '
<table style="border-collapse:collapse" border="1" align="left" width=47%;>
<colgroup valign="bottom">';
/*
<tr>
<th align="center" width="15%"><b>RollNo</b></th>
<th align="center" width="85%" ><b>Name</b></th>

</tr>;*/

$stud_details = $conn->query("select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class' and current_class.rollno <= 35 order by current_class.rollno ASC");
    while($res_stud_details = $stud_details->fetch_array())
    {
        $sid=$res_stud_details[0];
        $name=$res_stud_details[1];
    $html.='
        <tr style="line-height:5.17mm">
            <td align="center"  valign="middle">'.$sid.'</td>
            <td valign="middle" align="center">'.strtoupper($name).'</td> 
        </tr>';
}
$html.= '  </table>';
$html .= '
<table style="border-collapse:collapse" border="1" align="right" width=47%;>
<colgroup valign="bottom">';
/*
<tr>

<th align="center" width="15%"><b>RollNo</b></th>
<th align="center" width="85%" ><b>Name</b></th>

</tr>;
*/

$stud_details = $conn->query("select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class' and current_class.rollno > 35 order by current_class.rollno ASC");
    while($res_stud_details = $stud_details->fetch_array())
    {
        $sid=$res_stud_details[0];
        $name=$res_stud_details[1];
    $html.='
        <tr style="line-height:5.17mm">
            <td align="center"  valign="middle">'.$sid.'</td>
            <td valign="middle" align="center">'.strtoupper($name).'</td> 
        </tr>';
}
$html.= '  </table>';
$html.='<br/><br/> ';

$html.="</body>";
$html.="</html>";
$dompdf->loadHtml(html_entity_decode($html));	
$dompdf->setPaper('A4', 'portrait'); //portrait or landscape
$dompdf->render();
$dompdf->stream("Roll List",array("Attachment"=>0));

?>       
