<?php
include("../include/header.php");
include("../include/connection.php");

$subjectid=$_GET['id'];
$fid=$_GET['fid'];
$i=1;

include("../include/sidenav.php");
include("../include/report_erros.php");



?>
<!DOCTYPE html>
<html>
<head>
	<title>
		remarks
	</title>
</head>
</body>
<div id="page-wrapper">
	<div class="container-fluid">
		<div class="row">
			<div class="col-lg-12">
				<h1 class="page-header">Remarks</h1>
			</div>
		</div>
		<form method="post">
			<?php
//current date
			$l=$conn->query("select acd_year from academic_year where status=1") or die(mysql_error());
			$r=$l->fetch_assoc();
			$prev=$r["acd_year"];

//...........query retrieving remarks
			$sq=$conn->query("SELECT qs12 FROM mainfeedback WHERE subjectid='$subjectid'and fid='$fid' and acdyear='$prev' and qs12!='' ");

			while ($re=$sq->fetch_array())
			{
				$row=$re['qs12'];
	//echo $row;
				echo $i.". ".$re['qs12'];
				$i=$i+1;
				echo "<br>";
			}
			?>
			<br>
			<input type="submit" class="btn btn-primary" name="submit" value="Back" align="middle"/>
			<?php
			if(isset($_POST["submit"]))
			{
				echo "<script>window.location.href='datasheet.php'</script>";

			}
			?>
		</form>
	</body>
	</html>

	<?php
	include("../include/footer.php");
	?>

