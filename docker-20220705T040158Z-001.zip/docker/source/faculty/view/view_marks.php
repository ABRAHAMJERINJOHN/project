<?php
//$con=mysqli_connect("localhost","root","","ritsoft2");
include("../include/connection.php");
//session_start();
//$uname=$_SESSION['fid'];

include("../include/header.php");
include("../include/sidenav.php");

$uname=12345;

//$uname=$_SESSION['fid'];


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Marks</title>
	<script src="jquery-1.9.1.min.js"></script>
	<script>
		 function showsub(str)
  {
    var xmlhttp;
    if (window.XMLHttpRequest)
    {
      xmlhttp=new XMLHttpRequest();
    }
    else
    {
      xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
    }

    xmlhttp.open("GET","get_sub.php?id="+str,true);
    xmlhttp.send();

    xmlhttp.onreadystatechange=function() 
    {
      if(xmlhttp.readyState==4 && xmlhttp.status==200)
      {
        document.getElementById("sub").innerHTML=xmlhttp.responseText;
        showDate ( str) ;
      }
    }
  }
		function get_assess_tool(sub_id){
			console.log(sub_id);
			var xmlhttp;
			if (window.XMLHttpRequest)
			{
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}

			xmlhttp.open("GET","get_assess_tool.php?id="+sub_id,true);
			xmlhttp.send();

			xmlhttp.onreadystatechange=function() 
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("assessment_tool").innerHTML=xmlhttp.responseText;

				}
			}
		}
	</script>
	<script>

		$(document).ready(function() {
			$("#sub").change(function () {
				var str = "";
				if ($("#sub option:selected").val()=='')
				{
				//$("#errmsg").html("Please select subject");
				 //$().message("Select subject!");
				 $('#btnshow').attr('disabled', 'disabled');  
			 }
			 else
			 {
			
				 $('#btnshow').removeAttr('disabled');
			 }
		 });
		});

	</script>
	<script type="text/javascript">
		function btn_active(){
			document.getElementById('btnshow').disabled = false;
		}
		function success() {
			if(document.getElementById("textd").value==="") { 
				document.getElementById('button').disabled = true; 
			} else { 
				document.getElementById('button').disabled = false;
			}
		}

	</script>
<script type="text/javascript">
	$(document).ready(function($) {
		$(document).on('click', '#nodatexl', function(event) {
			event.preventDefault(); 
			$this = $('#talbew'); 
			$html =  $this.html() + ""; 
			$('#gooddnowdatafor').find('input').val( $html );
			$('#gooddnowdatafor').submit();

		});
		
	});


</script>

</head>
<div id="page-wrapper">
	<body>
		<div class="map_contact">
			<div class="container">

				<h3 class="tittle">View Marks</h3>
				<div class="contact-grids" align="center">

					<div class="col-md-8 contact-grid" style="text-align:center;">
						<form method="post" enctype="multipart/form-data" action="">
							<table align="center" width="700" style="cellspacing:2px;" id="table_select_data">
								<tbody>
									<tr><td> Class</td>  <td>  
										<select name="class" class="form-control" onchange="showsub(this.value)">
											<option>select</option>
											<?php
											$c=$conn->query("select distinct(classid) from subject_allocation where fid='$uname'");

											while($res=$c->fetch_array())
											{
												$res1=$conn->query("select * from class_details where classid='$res[classid]' and active='YES'");
												while($rs=$res1->fetch_array())
												{
													?>
													<option value="<?php echo $rs['classid'].",".$rs['courseid'].",S".$rs['semid'].",".$rs['branch_or_specialisation'];?>">
														<?php echo $rs['courseid'];?>,S<?php echo $rs['semid'];?>,<?php echo $rs['branch_or_specialisation'];?></option>
														<?php
													}
												}
												?>
											</select>
										</td>
									</tr>
												

										<tr>
											<td><h5 style="margin-top: 25px;">Subject</h5></td> 
											<td>
												<div id="sub" style="margin-top: 25px;">
													<select name="sub" class="form-control" onchange="get_assess_tool()">
														<option>select</option>
													</select>
												</div> 
											</td>
										</tr>
										<tr>
											<td><h5 style="margin-top: 25px;">Assessment Tool</h5></td>
											<td>
												<div id="assessment_tool_div" style="margin-top: 25px;">
													<select name="assessment_tool" id="assessment_tool" class="form-control">
														<option>select</option>

													</select>
												</div> 
											</td>
										</tr>
										<tr><td></td><td><input type="submit" name="btnshow" id="btnshow" style="margin-top: 25px;" class="btn btn-primary" value="View" />  </td></tr> 
						</form>
										<div style="margin-top: 25px;">
									<!-- <form name="form1" method="post" id="fom_excel_serie_su_suer"> -->
										<div class="" style="text-align:center">
											<style type="text/css">
												.iamloading .resulttable, .imagepare {
													display: none;												
												}
												.iamloading .imagepare, .resulttable {
													display: block;
												}
											</style>
										<div id="outputData" class=" ">
											<div class="imagepare" style="text-align: center;">
												<img style="width: 50px; padding: 3pc 0;" src="../images/loading.gif">
											</div>
											<?php
											include("../include/connection.php");
											if(isset($_POST['btnshow']))
											{
												$assess_tool_id = $_POST['assessment_tool'];
												$sub_id = $_POST['sub'];
												$class_details = explode(",",$_POST['class']);
                                                $class_id = $class_details[0];
												$sem = $class_details[2];
												$dept = $class_details[1];

												$get_tool_details = $conn->query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id'");
												$tool_details_count = $get_tool_details->num_rows();
												if($tool_details_count > 0){
													
													$get_assess_tool = $conn->query("Select * from accreditation_assesment_tool where tool_id='$assess_tool_id'");
													while($res_assess_tool = $get_assess_tool->fetch_array() ){
														$asses_tool_name = $res_assess_tool['name'];
														$no_of_questions = $res_assess_tool['no_of_questions'];
													}

													$get_subject_details = $conn->query("Select * from subject_class where subjectid='$sub_id'");
													while($res_subject_details = $get_subject_details->fetch_array() ){
														$subject_title = $res_subject_details['subject_title'];

													}
													?>
												
												<!-- <div id="outputData" class=" "> -->
													<!-- <div class="table-responsive"> -->
														                                        
														<table id="talbew_head" class="table table-hover table-bordered" style="margin-top: 25px;">	

															<tr>
																<td colspan="7" align="left">
																	<strong><font face="Calibri">I : Details of marks obtained by individual students in <?php echo $asses_tool_name; ?></font></strong>
																</td>
																<td>
																	<button class="btn btn-primary" type="button" data-toggle="modal" data-target="#edit_co_details">Edit</button>
																</td>
															</tr>

															<tr>
																
																<td>
																	<strong>Subject :</strong>
																</td>
																<td>
																	<strong> <?php echo $sub_id; ?> </strong>
																</td>
																<td colspan="3">
																	<strong><?php echo $subject_title; ?></strong>
																</td>
																<td >
																	<strong>Class :</strong>
																</td>
																<td>
																	<strong><?php echo $sem.' '.$dept; ?></strong>
																</td>
																<td>
																	<strong>2021-22</strong>
																</td>

														</tr>
														<tr>
															<td colspan="3" align="right">Question Number</td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
															?>
																<td><?php echo $questions; ?></td>

															<?php
																}
															?>
															
														</tr>
														<tr>
															
															<td colspan="3" align="right" >Mapped CO Number</td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
                                                                    
                                                                    $get_assess_details = mysql_query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'",$con);
                                                                    while($res_assess_tool_details = mysql_fetch_array($get_assess_details) ){
																		$sqlnew =  $conn->query("select co_code from course_outcome where co_id = $res_assess_tool_details[3]");
																		while($res_new = $sqlnew->fetch_array()){

															?>
																<td ><?php echo $res_new[0]; ?></td>

															<?php
																		}
                                                                    }
																}
															?>
														</tr>
														<tr>
															<td colspan="3" align="right" >Max. Mark for the question</td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
                                                                    $get_assess_details = $conn->query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'");
                                                                    while($res_assess_tool_details = $get_assess_details->fetch_array() ){                                                                    
															?>
																<td ><?php echo $res_assess_tool_details[4]; ?></td>
															<?php
                                                                    }
																}
															?>
														</tr>
                                                        <tr>

                                                	    </tr>
													</table>
													<!-- Modal -->
													<div class="modal fade" id="edit_co_details" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                						<div class="modal-dialog modal-dialog-centered" role="document">
                                						    <div class="modal-content">
                                						        <div class="modal-header">
                                						            <h4 class="modal-title" id="exampleModalLongTitle">Edit Mapped CO & Max</h4>
                                						            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                						                <span aria-hidden="true">&times;</span>
                                						            </button>
                                						        </div>
                                						        <form method="POST" action="edit_mapped_co.php">
                                						            <div class="modal-body">
																		<table class="table table-hover table-bordered">
																			<tr>
																				<td colspan="3" align="right">Question Number</td>
																				<?php 
																					for($questions=1; $questions<=$no_of_questions; $questions++){
																				?>
																					<td><?php echo $questions; ?></td>
																					
																				<?php
																					}
																				?>
																			</tr>
																			<tr>
																				<td colspan="3" align="right" >Mapped CO Number</td>
																				<?php 
																					for($questions=1; $questions<=$no_of_questions; $questions++){
																						$get_assess_details = $conn->query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'");
																						while($res_assess_tool_details = $get_assess_details->fetch_array() ){
																							$sqlnew =  $conn->query("select co_code from course_outcome where co_id = $res_assess_tool_details[3]");
																							while($res_new = $sqlnew->fetch_array()){
                                                        					            
																				?>
																					<td >
																						<?php
																							echo "<select name='mapped_cos$questions' style='width:60px;'>";
																							$get_co = $conn->query("Select * from course_outcome where subject_id='$sub_id'");
																								while($res_co = mysql_fetch_array($get_co)){
																						?>
																									<option value='<?php echo $res_co[0]; ?>' <?php if($res_co[2] == $res_new[0]){ echo 'selected'; } ?>><?php echo $res_co[2]; ?></option>
																						<?php
																							}
																							echo "</select>"; 
																						?>
																						<!-- <input type="text" name="<?php //echo 'mapped_cos'.$questions; ?>" value="<?php //echo $res_new[0]; ?>" style="width: 60px;"> -->
																					</td>
																							
																				<?php
																							}		
																						}
																					}
																				?>
																			</tr>
																			<tr>
																				<td colspan="3" align="right" >Max. Mark for the question</td>
																				<?php 
																					for($questions=1; $questions<=$no_of_questions; $questions++){
                                                        					            $get_assess_details = $conn->query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'");
                                                        					            while($res_assess_tool_details = $get_assess_details->fetch_array() ){                                                                    
																				?>
																					<td ><input type="text" name="<?php echo 'max_marks'.$questions; ?>" value="<?php echo $res_assess_tool_details[4]; ?>" style="width: 60px;"></td>
																				<?php
                                                        					            }
																					}
																				?>
																			</tr>
																		</table>
																		<input type="hidden" name="assess_tool_id" value="<?php echo $assess_tool_id; ?>">
																		<input type="hidden" name="no_of_qstn" value="<?php echo $no_of_questions; ?>">
                                						            </div>
                                						            <div class="modal-footer">
                                						                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                						                <button type="submit" class="btn btn-primary" name="btn_mappedco" id="btn_mappedco">Save changes</button>
                                						            </div>
                                						        </form>
                                						        
						
                                						    </div>
                                						</div>
                            						</div>
												<!-- </form> -->
														<table id="talbew" class="table table-hover table-bordered" style="margin-top:25px;">
										        	    	<tr>
										        	    		<td>rollno</td>
										        	    		<td colspan="3">Name</td>
										        	    		<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
																?>
																<td>Q<?php echo $questions; ?></td>
																<?php
																	}
																?>
																<td>Edit</td>
										        	    	</tr>
                                                	        <?php
                                                	            $stud_details = $conn->query("select current_class.rollno,stud_details.name,current_class.studid from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class_id' order by current_class.rollno ASC");
                                                	            while($res_stud_details = $stud_details->fetch_array())
                                                	            { 
                                                	        ?>
                                                	        <tr>
                                                	            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                                	                <?php echo $res_stud_details[0]; ?>
                                                	            </td>
                                                	            <td colspan="3" style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                                	                <?php echo $res_stud_details[1]; ?>
                                                	            </td>
																<?php
                                                                
                                                                    $admission_no = $res_stud_details[2]; 
																    for($questions=0; $questions<$no_of_questions; $questions++){
                                                                        $get_assess_data = $conn->query("select marks from accreditation_assesment_data where admission_no='$admission_no' and tool_id='$assess_tool_id' ");
                                                                        while($res_assess_data = $get_assess_data->fetch_array()){
                                                                            $marks = explode(",",$res_assess_data[0]);
																    ?>
																    <td>
																    	<?php echo $marks[$questions]; ?>                                                               
																    </td>
																<?php
																	    }
                                                                    }
																?>
																<td>
																	<button  type="button" class="btn btn-sm btn-primary" data-toggle="modal" data-target="#<?php echo $admission_no ?>ModalCenter"><i class="fa fa-pencil"></i></button>                                                              
																</td>
                                                	        </tr>
															<!-- Modal -->
															<div class="modal fade" id="<?php echo $admission_no ?>ModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
                                								<div class="modal-dialog modal-dialog-centered" role="document">
                                								    <div class="modal-content">
                                								        <div class="modal-header">
                                								            <h4 class="modal-title" id="exampleModalLongTitle">Edit Assessment Tool</h4>
                                								            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                								                <span aria-hidden="true">&times;</span>
                                								            </button>
                                								        </div>
                                								        <form method="POST" action="edit_student_marks.php">
                                								            <div class="modal-body">
																				<?php
																					for($questions=0; $questions<$no_of_questions; $questions++){
																						$qn= $questions+1;
                                                                				        $get_assess_data = $conn->query("select marks from accreditation_assesment_data where admission_no='$admission_no' and tool_id='$assess_tool_id' ");
                                                                				        while($res_assess_data = $get_assess_data->fetch_array()){
                                                                				            $marks = explode(",",$res_assess_data[0]);
																				    ?>
																					<fieldset class="form-group">
			                    								                		<label for="co_name"><?php echo 'Question '.$qn; ?></label>
                                								                    		<input class="form-control" type="text" value="<?php echo $marks[$questions]; ?>" name="<?php echo 'q'.$qn; ?>">         
																					</fieldset>
																				    
																				<?php
																					    }
                                                                				    }
																				?>
                                								                
                                								            </div>
                                								            <input type="hidden" name="admission_no" value="<?php echo $admission_no; ?>">
                                								            <input type="hidden" name="no_of_questions" value="<?php echo $no_of_questions; ?>">
                                								            <input type="hidden" name="assess_tool_id" value="<?php echo $assess_tool_id; ?>">
                                								            <div class="modal-footer">
                                								                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                								                <button type="submit" class="btn btn-primary" name="submit" id="submit">Save changes</button>
                                								            </div>
                                								        </form>
                                								        
								
                                								    </div>
                                								</div>
                            								</div>
                                                	        <?php
                                                	            }
                                                	        ?>
										        	    </table>
														<!--  -->
													<!-- </div> -->
												</div>
											</body>
										</div>
										<!-- <div class="col-md-8 contact-grid" style="text-align:center ; margin-bottom: 1pc; margin-top:15px;">
											<input type="submit" class="btn btn-primary" name="submit_details"  value="Submit"/>   
										</div> -->
								</div>
							</div>
						
				</div>

			</div>
		</div>

<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<?php
}
else{
    echo "<script>alert('No Data Available..')</script>";
	echo "<script>window.location.href='view_marks.php'</script>";
}
												
}
?>


</body>

</html>

<?php

include("../include/footer.php");
?>