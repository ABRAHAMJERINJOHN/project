<?php
include("includes/header.php");
include("includes/sidenav.php");
include("includes/connection3.php");

$st=$_SESSION['fid'];



?>


<div id="page-wrapper">
  <link href="jquery-ui.css" rel="stylesheet">
  <script src="jquery.js" type="text/javascript"></script>
  <script src="jquery-ui.js" type="text/javascript"></script>
  
</head>
<body>
  <div class="map_contact">
   <div class="container">

    <h3 class="tittle"></h3>
    <div class="contact-grids" align="center">

     <div class="col-md-8 contact-grid" style="text-align:center">
      <form method="post" enctype="multipart/form-data"><br><br><br>
        <h2>Add CO Level</h2>

        <table  align="center" width="700" class="table table-hover table-bordered">

          
            <tr>
                <td>
                    <label>Percentage of students for attainment level 1</label> </td>
                <td>
                    <input type="number" class="form-control" name="co_level1" min="1" max="100">
                </td>
            </tr>
            <tr>
                <td><label>Percentage of students for attainment level 11</label></td>
                <td>
                    <input type="number" class="form-control" name="co_level2" min="1" max="100">
                </td>
            </tr>
            <tr>
                <td><label>Percentage of students for attainment level 111</label></td>
                <td>
                    <input type="number" class="form-control" name="co_level3" min="1" max="100">
                </td>
            </tr>
            
       </table>

  <input type="submit" name="add_co_level"  value="Add " class="btn btn-primary" />
  
</form>

<?php
    if(isset($_POST['add_co_level']))
    {
        $class=explode(",",$_POST['class']);
        $class_name = $class[2].' '.$class[1];
        $subject_id=explode("-",$_POST['sub']);
        $category_id=$_POST['tool_category'];
        $name=$_POST['tool_name'];
        $no_of_questions=$_POST['num_of_questions'];
        $weightage=$_POST['weightage'];
        $target=$_POST['target'];
        $status = 1;
        $sql = mysql_query( "insert into accreditation_assesment_tool(class_id,subjectid,category_id,name,no_of_questions,weightage,target_percentage,status)VALUES ('$class_name','$subject_id[0]','$category_id','$name','$no_of_questions',$weightage,$target,'$status')",$con);
        if ($sql) {
            echo "<script>alert('Succesfully Added')</script>";
            echo "<script>window.location.href='assesment_tool.php'</script>";
        } else {
            echo "<script>alert('Failed to Add')</script>";
            echo "<script>window.location.href='assesment_tool.php'</script>";
        
        }
    }
?>
</body>
</html>
<?php include("includes/footer.php");   ?>
