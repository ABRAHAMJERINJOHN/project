<?php
$con1=mysql_connect("127.0.0.1","ritsoftv2","ritsoftv2");
mysql_select_db("ritsoftv2",$con1);
?>
