<?php
    include("includes/connection3.php"); 
    // $get_subject = mysqli_query($con3,"select subjectid from accreditation_assesment_tool where tool_id='26'");
    // $res_sub = mysqli_fetch_array($get_subject);
    // while($res_sub){
    //     echo $res_sub[0];
    // }
    if(isset($_POST['btn_mappedco'])){
		$assess_tool_id = $_POST['assess_tool_id'];
		$no_of_qstn = $_POST['no_of_qstn'];
		for($question=1;$question<=$no_of_qstn;$question++)
		{
			$mapped_co = $_POST['mapped_cos'.$question];
			$max_mark = $_POST['max_marks'.$question];
            // echo $question.' - '.$mapped_co.' - '.$max_mark.'<br>';
			$update_mapped_co = mysqli_query($con3,"update accreditation_assesment_tool_details set mapped_co='$mapped_co',max_mark='$max_mark' where tool_id='$assess_tool_id' and question_no='$question' ");
        }
        if ($update_mapped_co) {
            echo "<script>alert('Succesfully Updated')</script>";
            echo "<script>window.location.href='view_marks.php'</script>";
        } else {
            echo "<script>alert('Failed to Update')</script>";
            echo "<script>window.location.href='View_marks.php'</script>";
        
        }
        
	}
?>