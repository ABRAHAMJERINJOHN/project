<?php
    include("includes/connection3.php"); 
    if(isset($_POST['submit']))
    {
		$adm_no = $_POST['admission_no'];
		$no_of_qstn = $_POST['no_of_questions'];
		$assess_tool_id = $_POST['assess_tool_id'];
		$mark_string = '';
        for($question=1;$question<=$no_of_qstn;$question++){
			$qstn_string = 'q'.$question;
			$marks = $_POST[$qstn_string];
			if($mark_string == ''){
				if($marks == ''){
					$mark_string = ',';
				}
				else{
					$mark_string = $marks.',';
				}
			}
			else{
				if($marks == ''){
					if($question == 2){
						$mark_string = $mark_string.'';
					}
					else{
						$mark_string = $mark_string.',';
					}
				}
				else{
					if($question == 2){
						$mark_string = $mark_string.$marks;
					}
					else{
						$mark_string = $mark_string.','.$marks;
					}
				}
			}
		}
	
	
        $update = mysqli_query($con3,"update accreditation_assesment_data set marks='$mark_string' WHERE tool_id='$assess_tool_id' and admission_no='$adm_no' ");
        if ($update) {
            echo "<script>alert('Succesfully Updated')</script>";
            echo "<script>window.location.href='view_marks.php'</script>";
        } else {
            echo "<script>alert('Failed to Update')</script>";
            echo "<script>window.location.href='View_marks.php'</script>";
		
        }
    } 

?>