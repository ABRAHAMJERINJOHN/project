<?php  

include 'PHPExcel/IOFactory.php';

$arrayMark = array();
include("connection.php");

if (!isset($_FILES['selected_excel'])) {
	echo '<div class="alert alert-danger"> <strong>danger!</strong> unknown file type</div>'; 
} else {

	$target_dir = "uploads/";
	$target_file = $target_dir . basename($_FILES["selected_excel"]["name"]);
	$uploadOk = 1;
	
	$assess_tool_id = $_POST['ass_tool_id'];
	$get_assess_tool = mysql_query("Select * from accreditation_assesment_tool where tool_id='$assess_tool_id'");
	while($res_assess_tool = mysql_fetch_array($get_assess_tool) ){
		$asses_tool_name = $res_assess_tool['name'];
		$no_of_questions = $res_assess_tool['no_of_questions'];
	}
	$class_id = $_POST['class_id'];
	$get_stud_details = mysql_query("select studid from current_class where classid='$class_id' order by rollno ASC");
    $res_stud = mysql_num_rows($get_stud_details);
	$res_stud++;
	if(isset($_POST["class_id"]) && isset($_POST["sub_code"])) { 
		$allowed =  array('xls','xlsx');
		$filename = $_FILES['selected_excel']['name'];
		$ext = pathinfo($filename, PATHINFO_EXTENSION); 

		if(!in_array($ext,$allowed) ) { 
			echo '<div class="alert alert-danger"> <strong>danger!</strong> unknown file type</div>'; 
		} else { 

			$inputFileName = $_FILES["selected_excel"]["tmp_name"];
			try {
				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);
			} catch(Exception $e) {
				$ydie = 'Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage();

				echo '<div class="alert alert-danger"> <strong>danger!</strong>$ydie</div>'; 
			}


			$sheet = $objPHPExcel->getSheet(0);
			$highestRow = $sheet->getHighestRow(); 
			$highestColumn = $sheet->getHighestColumn();

			$outputArray = array();
			for($row = 2; $row <= $res_stud; $row++)
			{
				$temp = array();
				$startingAlphabet = "E";
				for($ques = 1; $ques<=$no_of_questions;$ques++)
				{
					$tempVar = $startingAlphabet.$row;
					$newVar = $sheet->getCell(''.$tempVar)->getValue();
					$temp['Q'.$ques] = $newVar;
					$startingAlphabet++;
				}
				//$temp['total'] = $sheet->getCell($startingAlphabet.$row)->getValue();
				array_push($outputArray,$temp);
			}
			// $identifr = "rollno";
			// $targert = "Q1";
			// $targert2 = "Q2";




			// $identifr = trim($identifr," ");
			// $targert = strtolower($targert );
			// $targert2 = strtolower($targert2 );

			// $identifrid = -1;
			// $targertid = -1;
			// $targertid2 = -1;

			// for ($row = 1; $row <= $highestRow; $row++){ 
			// 	$rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
			// 		NULL,
			// 		TRUE,
			// 		FALSE);
			// 	if( $identifrid < 0 || $targertid < 0 || $targert2 < 0){
			// 		foreach ($rowData[0] as $key => $value) {
			// 			$value = trim($value," ");
			// 			$value = strtolower($value);

			// 			$identifr = trim($identifr," ");
			// 			$targert = strtolower($targert );
			// 			$targert2 = strtolower($targert2 );

			// 			if($value == $identifr )
			// 				$identifrid = $key;

			// 			if($value == $targert )
			// 				$targertid = $key;

			// 			if($value == $targert2 )
			// 			$targertid2 = $key;

			// 		}
			// 	} else { 
			// 		array_push($arrayMark , array(
			// 			'id' =>  strtolower($rowData[0][ $identifrid ] ) ,
			// 			'value1' => strtolower($rowData[0][ $targertid ] ),
			// 			'value2' => strtolower($rowData[0][ $targertid2 ] )
			// 		));
			// 	}


			// }

			// if( $identifrid < 0 && $targertid < 0 && $targertid2 < 0) {  
			// 	echo '<div class="alert alert-danger"> <strong>danger!</strong>cannot find any valid data</div>'; 
			// }  

			if( empty($outputArray) ) {  
				echo '<div class="alert alert-warning"> <strong>warning!</strong>cannot find any valid data</div>'; 
			}  
		}
	}

}
?>
<?php
	include("connection.php");
		
		$isSet = false;

		$assess_tool_id = $_POST['ass_tool_id'];
		$sub_id = $_POST['sub_code'];
		// $class_details = explode(",",$_POST['class']);
		$class_id = $_POST['class_id'];
		$sem = $_POST['sem'];
		$dept = $_POST['dept'];
		$get_assess_tool = mysql_query("Select * from accreditation_assesment_tool where tool_id='$assess_tool_id'");
		while($res_assess_tool = mysql_fetch_array($get_assess_tool) ){
			$asses_tool_name = $res_assess_tool['name'];
			$no_of_questions = $res_assess_tool['no_of_questions'];
		}

		$get_subject_details = mysql_query("Select * from subject_class where subjectid='$sub_id'");
		while($res_subject_details = mysql_fetch_array($get_subject_details)){
			$subject_title = $res_subject_details['subject_title'];
		}
		echo "<form method='post' name='new_excel_form'>";
		echo "<div class='table-responsive'>";
		echo "<table id='talbew' class='table table-hover table-bordered' style='margin-top: 25px; width:100%'>";
		echo "<tr>";
		echo "<td colspan='11' align='left'>";
		echo "<strong><font face='Calibri'>I : Details of marks obtained by individual students in  $asses_tool_name </font></strong>";
		echo "</td>";
		echo "</tr>";
		echo "<td></td>";
		echo "<td>";
		echo "<strong>Subject :</strong>";
		echo "</td>";
		echo "<td>";
		echo "<strong> $sub_id </strong>";
		echo "</td>";
		echo "<td colspan='3'>";
		echo "<strong>$subject_title</strong>";
		echo "</td>";
		echo "<td>";
		echo "<strong>Class :</strong>";
		echo "</td>";
		echo "<td>";
		echo "<strong>$sem  $dept</strong>";
		echo "</td>";
		echo "<td>";
		echo "<strong>2021-22</strong>";
		echo "</td>";
		echo "</tr>";
		echo "<tr>";
		echo "<td></td>";
		echo "<td colspan='10'></td>";
		echo "</tr>";
		echo "<tr>";
		echo "<td></td>";
		echo "<td colspan='3' align='right' bgcolor='#d8d8d8'>Question Number -></td>";
		for($questions=1; $questions<=$no_of_questions; $questions++){
			echo "<td bgcolor='#d8d8d8'>";
			echo "<strong>$questions</strong>";
			echo "</td>";
		}
		echo "</tr>";
		echo "<tr>";
		echo "<td></td>";
		echo "<td colspan='3' align='right' bgcolor='#d8d8d8'>Mapped CO Number -></td>";
		for($questions=1; $questions<=$no_of_questions; $questions++){
			echo "<td bgcolor='#d8d8d8'><select name='mapped_cos$questions' style='width:60px;' required>";
			$get_co = mysql_query("Select * from course_outcome where subject_id='$sub_id'");
			while($res_co = mysql_fetch_array($get_co)){
				echo "<option value='$res_co[0]'>$res_co[2]</option>";
			}
			echo "</select'></td>";
		}
		echo "</tr>";
		echo "<tr>";
		echo "<td></td>";
		echo "<td colspan='3' align='right' bgcolor='#d8d8d8'>Max. Mark for the question -></td>";
		for($questions=1; $questions<=$no_of_questions; $questions++){
			echo "<td bgcolor='#d8d8d8'><input type='text' name='max_marks$questions' style='width:60px;' required></td>";
		}
		echo "</tr>";
		echo "<tr>";
		echo "</tr>";
		echo "<tr>";
		echo "<td>Roll No</td>";
		echo "<td colspan='3'>Name</td>";
		for($questions=1; $questions<=$no_of_questions; $questions++)
		{
			echo "<td>Q$questions</td>";
		}
		// echo "<td>Total</td>";
		echo "</tr>";
		$stud_details = mysql_query("select current_class.rollno,stud_details.name,current_class.studid from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class_id' order by current_class.rollno ASC");
        while($res_stud_details = mysql_fetch_array($stud_details))
        {
			echo "<tr>";
			echo "<td style='border: 1px solid #dddddd; text-align: left; padding: 4px;'>";
			echo $res_stud_details[0];
			$studId = (int)$res_stud_details[0] - 1;
			echo "</td>";
			echo "<td colspan='3' style='border: 1px solid #dddddd; text-align: left; padding: 4px;'>";
			echo $res_stud_details[1];
			//echo print_r($outputArray);
			$student_id = $res_stud_details[2];
			echo "</td>";
			for($questions=1; $questions<=$no_of_questions; $questions++){
				$qstn_string = 'q'.$questions;
				$val = $outputArray[''.$studId]['Q'.$questions];
				echo "<td><input type='text' id='q$questions' onkeyup='success()' name='$student_id$qstn_string' style='width:50px;' value='$val'></td>";
			}
			// 	foreach ($arrayMark as $key => $value) { 
			// 		if($value["id"] == strtolower( trim( $res_stud_details[0]  , ' ' ) ) ){
			// 			echo trim($value["value"], ' '); 
			// 			$isSet = true;
			// 		}
			// 	}
			// 	echo "'></td>";
			// }
			// echo "<td><input type='number' id='textd' onkeyup='success()' required='true' step='.01' name='marks$res_stud_details[2]'  value='";
			// foreach ($arrayMark as $key => $value) { 
			// 	if($value["id"] == strtolower( trim( $res_stud_details[0]  , ' ' ) ) ){
			// 		echo trim($value["value"], ' '); 
			// 		$isSet = true;
			// 	}
			// }
			// echo "'>";
			// echo "</td>";
			//echo "<td><input type='text' id='total' name='total' style='width: 50px;'></td>";
			echo "</tr>";
		}
		echo "</table>";
		echo "<input type='hidden' name='a_tool_id' value='$assess_tool_id'>";
		echo "<input type='hidden' name='no_of_qstn' value='$no_of_questions'>";
		echo "<input type='hidden' name='classId' value='$class_id'>";
		echo "</div>";
		echo "<div class='col-md-8 contact-grid' style='text-align:center ; margin-bottom: 1pc; margin-top:15px;'>";
		echo "<input type='submit' class='btn btn-primary' name='submit_details'  value='Submit'/>";
		echo "</div>";							
			?>
			
<?php
if ($isSet) {
	?>
	<!-- <div class="col-md-8 contact-grid " style="text-align:center ; margin-bottom: 1pc;"> -->
		<!-- <input type="submit" class="btn btn-primary" name="submit_details"  value="Submit"/>    -->
		<!--<input type="reset" class="btn btn-primary" onclick="window.location.href='hos.php'" value="clear" />-->
	<!-- </div>
	</form> -->
	<?php
} else {
	?>

	<!-- <div class="col-md-8 contact-grid " style="text-align:center ; margin-bottom: 1pc;">
		<input type="submit" class="btn btn-primary" id="button" name="submit" disabled ="disabled" value="Save"/>   <!--<input type="reset" class="btn btn-primary" onclick="window.location.href='hos.php'" value="clear" />-->

	</div>
	<?php
}
?>
