<?php
session_start();
//$con=mysqli_connect("localhost","root","","ritsoft3");
include("includes/connection1.php"); 
$username=$_SESSION['fid'];
$sub_id=$_REQUEST['id'];

?>
<script>
alert("<?php echo $sub_id;?>");
</script>
<select name="assessment_tool" id="assessment_tool" class="form-control" onchange="btn_active();">
<option>select</option>
<?php
$c=mysqli_query($con,"select * from  accreditation_assesment_tool where subjectid='$sub_id'");
while($re=mysqli_fetch_array($c))
{

?>
<option value="<?php echo $re['tool_id'];?>"><?php  echo $re['name'];?></option>
<!--<option value="<?php //$subt=$re['subjectid']; echo $re['subjectid'];?>"><?php  //echo $re['subject_title'];?></option>-->
<?php
}
?>
</select>
