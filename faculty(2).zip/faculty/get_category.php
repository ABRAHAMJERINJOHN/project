<?php
session_start();
include("includes/connection3.php"); 
//$con=mysqli_connect("localhost","root","","ritsoft");
//error_reporting(0);
$username=$_SESSION['fid'];
$category_id=$_REQUEST['id'];

?>
<script>
	alert("<?php echo $id;?>");
</script>
<select onchange="getWeightage(this.value)" name="tool_category" id="tool_category"  class="form-control" required="required">
	<option selected="selected" disabled="disabled" value="-1">select</option>
	<?php
	$c=mysqli_query($con3,"SELECT * FROM accreditation_assessment_tool_category where category_type = '$category_id'");
	while($re=mysqli_fetch_array($c))
	{
		?>
		<option value="<?php echo $re['ass_category_id'];?>"><?php  echo $re['category_name'];?></option>
		<?php
	}
	?>
</select>