<?php
//$con=mysql_connect("localhost","root","")or die("server not found");
//mysql_select_db("ritsoft33",$con)or die("database not found");
?>

<?php
$con=mysql_connect("127.0.0.1","ritsoftv2","ritsoftv2")or die("server not found");
mysql_select_db("ritsoftv2",$con)or die("database not found");
?>
