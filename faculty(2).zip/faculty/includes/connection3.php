<?php
$con3=mysqli_connect("127.0.0.1","ritsoftv2","ritsoftv2","ritsoftv2")or die("server not found");

?>
