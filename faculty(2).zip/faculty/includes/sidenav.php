 <div class="navbar-default sidebar" role="navigation">
  <div class="sidebar-nav navbar-collapse">
    <ul class="nav" id="side-menu">
                           <!-- <li class="sidebar-search">
                          <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                           /input-group 
                         </li>-->
                         <li>
                          <a href="dash_home.php"><i class="fa fa-user fa-fw"></i>                                <?php
                          include("includes/connection.php");
                          $fid=$_SESSION["fid"];

                          $r=mysql_query("select name, deptname from faculty_details where fid='$fid'",$con);  
                          while($d=mysql_fetch_array($r))
                          {
                           $fname=$d["name"];
                           $dname=$d["deptname"];

                         }
                         echo $fname;
                         ?>       
                       </a>
                     </li>
                     <li> 
                      <!-- <a href="home1.php"><i class="fa fa-table fa-fw"></i>SESSIONAL MARKS</a> -->
                      <a href="#"><i class="fa fa-table fa-fw"></i>SESSIONAL MARKS<span class="fa arrow"></span></a>

                      <!-- /.nav-second-level -->

                      <ul class="nav nav-second-level">

                       <li>
                        <!-- <a href="hos.php">Enter Final</a> -->
                        <a href="hos.php">Enter</a>
                      </li>
                      <li>
                        <a href="new1.php">View</a>
                      </li>
                      <li>
                        <a href="hos11.php">Edit</a>
                      </li>


                    </ul>

                  </li>
                  <li> 
                    <!-- <a href="home1.php"><i class="fa fa-table fa-fw"></i>SESSIONAL MARKS</a> -->
                    <a href="#" style="text-transform: uppercase;"><i class="fa fa-table fa-fw"></i>series MARKS<span class="fa arrow"></span></a>

                    <!-- /.nav-second-level -->

                    <ul class="nav nav-second-level">
                     <li>
                      <a href="each_series_mark.php">Enter Mark</a>
                    </li> 
                    <li>
                      <a href="each_series_mark_view.php">View</a>
                    </li> 

                  </ul>






                </li>
                <li>
                  <a href="search-form.php"><i class="fa fa-edit fa-fw"></i> STUDENT SEARCH</a>
                </li>
                <li>
                  <a href="datasheet.php"><i class="fa fa-align-justify"></i>VIEW FEEDBACK</a>
                </li>



                <li>
                  <a href="#"><i class="fa fa-align-justify"></i> ATTENDANCE<span class="fa arrow"></span></a>

                  <ul class="nav nav-second-level">
                   <li>
                    <a href="hos_att.php">Enter Attendance</a>
                  </li>
                  <li>
                    <a href="hos_update.php">Edit Attendance</a>
                  </li>
                  <li>
                   <!-- <a href="hos_update_hour.php">Edit Hour</a> -->
                  </li>

                  <li>
                   <!-- <a href="hos_update_date.php">Edit date</a> -->
                  </li>


                  <li>
                    <a href="single_sub_staff_view.php">View</a>
                  </li>
                  <li>
                    <a href="hos_delete_hour.php">Delete</a>
                  </li>

                  <li>
                    <a href="export_duty_leave.php">Duty Leave</a>
                  </li>

                   <li>
                    <a href="attendance_status.php">Attendance Status</a>
                  </li>
                  <li>
                   <a href="view_attendance_report.php">Attendance Report</a> 
                  </li>
                  </ul>

                   

                

              </li>
              <!--<li><a target="_blank"  href="../ritstaffmngt.php"> <i class="fa fa-sign-out fa-fw"></i>RIT Staff Management Portal</a></li> -->


            

            
                <li> 
                     
                      <a href="#"><i class="fa fa-table fa-fw"></i>ROLL LIST<span class="fa arrow"></span></a>
                      <ul class="nav nav-second-level">

                       <li>
                      
                        <a href="roll_list.php"> View</a>
                       </li>
                     

                      </ul>

                </li>  
                <li> 
                     
                    <a href="#"><i class="fa fa-table fa-fw"></i>ASSESMENT TOOLS<span class="fa arrow"></span></a>
                    <ul class="nav nav-second-level">

                      <li>
                        <a href="assesment_tool.php"> Add</a>
                      </li>
                      <li>
                        <a href="view_assesment_tool.php"> View</a>
                      </li>
                      <li>
                        <a href="upload_marks.php"> Upload Marks</a>
                      </li>
                      <li>
                        <a href="view_marks.php"> View Marks</a>
                      </li>

                    </ul>
                    <li> 
                     
                     <a href="#"><i class="fa fa-table fa-fw"></i>ATTAINMENT LEVEL<span class="fa arrow"></span></a>
                     <ul class="nav nav-second-level">
 
                       <li>
                      <li>
                        <a href="attainment_percentage.php">Attainment Percentage</a>
                      </li>
                        
                      <li>
                        <a href="view_attainment.php">View Attainment</a>
                      </li>
                        
                       
                    </ul>

                </li> 



          </div>
          <!-- /.sidebar-collapse -->
        </div>
        <!-- /.navbar-static-side -->
      </nav>
