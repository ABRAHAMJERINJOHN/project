<?php
include("header.php");
include("sidenav.php");
?>

<?php
include("footer.php");
?>