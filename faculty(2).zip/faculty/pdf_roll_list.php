<?php
include("includes/connection3.php");
require_once("dompdf/autoload.inc.php");
use Dompdf\Dompdf;
$dompdf = new Dompdf();

$class=$_GET['class'];


$html=""; 
$html.='<html>';
$html.='<head>';

$html.='</head>';
$html.='<body>';               
$html .= '
<table border="1" align="left" width=45%;>
<colgroup valign="bottom">
<tr>
<th align="center" width="15%"><b>RollNo</b></th>
<th align="center" width="85%" ><b>Name</b></th>

</tr>';

$stud_details = mysqli_query($con3,"select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class' and current_class.rollno <= 30 order by current_class.rollno ASC");
    while($res_stud_details = mysqli_fetch_array($stud_details))
    {
        $sid=$res_stud_details[0];
        $name=$res_stud_details[1];
    $html.='
        <tr>
            <td align="center" height="16" valign="middle">'.$sid.'</td>
            <td valign="middle" align="center">'.strtoupper($name).'</td> 
        </tr>';
}
$html.= '  </table>';
$html .= '
<table border="1" align="right" width=45%;>
<colgroup valign="bottom">
<tr>
<th align="center" width="15%"><b>RollNo</b></th>
<th align="center" width="85%" ><b>Name</b></th>

</tr>';

$stud_details = mysqli_query($con3,"select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class' and current_class.rollno > 30 order by current_class.rollno ASC");
    while($res_stud_details = mysqli_fetch_array($stud_details))
    {
        $sid=$res_stud_details[0];
        $name=$res_stud_details[1];
    $html.='
        <tr>
            <td align="center" height="16" valign="middle">'.$sid.'</td>
            <td valign="middle" align="center">'.strtoupper($name).'</td> 
        </tr>';
}
$html.= '  </table>';
$html.='<br/><br/> ';

$html.="</body>";
$html.="</html>";
$dompdf->loadHtml(html_entity_decode($html));	
$dompdf->setPaper('A4', 'portrait'); //portrait or landscape
$dompdf->render();
$dompdf->stream("Roll List",array("Attachment"=>0));

?>       
