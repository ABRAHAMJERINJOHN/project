<?php
include("includes/header.php");
include("includes/sidenav.php");
include("includes/connection3.php");

$st=$_SESSION['fid'];


$se = true;
?>

<div id="page-wrapper">
  <link href="jquery-ui.css" rel="stylesheet">
  <script src="jquery.js" type="text/javascript"></script>
  <script src="jquery-ui.js" type="text/javascript"></script>
  
<script>
    function printDiv() {

        var printContents = document.getElementById('printArea').innerHTML;
        var originalContents = document.body.innerHTML;

        document.body.innerHTML = printContents;

        window.print();

        document.body.innerHTML = originalContents;

        window.location.reload();
    }
</script>
</head>
<body>

  <div class="map_contact">
   <div class="container">

    <h3 class="tittle"></h3>
    <div class="contact-grids" align="center">

     <div class="col-md-8 contact-grid" style="text-align:center">
      <form method="post" enctype="multipart/form-data" action=""><br><br><br>
        <h2>View Roll List</h2>

        <table  align="center" width="700" class="table table-hover table-bordered">

          <tr><td><label>
          Class</label></td><td>
            <select name="class" onChange="showsub(this.value)" class="form-control">
              <option>select</option>
              <?php
              $c=mysqli_query($con3,"select distinct(classid) from subject_allocation where fid='$st'");

              while($res=mysqli_fetch_array($c))
              {
               $res1=mysqli_query($con3,"select *from class_details where classid='$res[classid]' and active='YES'");
               while($rs=mysqli_fetch_array($res1))
               {
                ?>
                <option value="<?php echo $rs['classid'].",".$rs['courseid'].",S".$rs['semid'].",".$rs['branch_or_specialisation'];?>">
                  <?php echo $rs['courseid'];?>,S<?php echo $rs['semid'];?>,<?php echo $rs['branch_or_specialisation'];?></option>
                  <?php       $dept=$rs['deptname'];
                  $cid=$rs['courseid'];
                  $bs=$rs['branch_or_specialisation'];
                }
              }
              ?>
            </select>

          </td></tr>
          <!-- <tr><td><label>Subject</label> </td> <td><div id="sub">
            <select name="sub" class="form-control">
              <option>select</option>
            </select></td>
          </tr>
          <tr id="batchP" style="display: none;">
            <td><label>Batch</label> </td>
            <td>
              <div id="batch"></div>
            </td>
          </tr> -->

          <!-- <tr>
            <td>

              <label>Date from</label> </td>



              <td id="pdate">  -->

                <!-- <input type="date" name="date1" id="date1" class="form-control" placehodler="dd/mm/yyyy" value="<?php //echo date("d/m/Y"); ?>" />   -->

              <!-- </td>


            </tr>
            <tr><td><label>Date to</label></td>
              <td>
                <div id="datex2"  style="display: none;"> -->


               <!--  <input type="date" name="date2" id="date2"class="form-control" placehodler="dd/mm/yyyy" value="<?php //echo date("d/m/Y"); ?>" />
               -->
             <!-- </div>



           </td>
         </tr> -->
       </table>
<!--<input type="date" name="date1" placehodler="dd/mm/yyyy" value="<?php //echo date("d/m/Y"); ?>" />
  <input type="date" name="date2" placehodler="dd/mm/yyyy" value="<?php //echo date("d/m/Y"); ?>" />-->
  <input type="submit" name="btnshow"  value="View Roll List" class="btn btn-primary" />
  &nbsp;
  &nbsp;
  &nbsp;
  &nbsp;
  <!--input type="submit" name="submit" value="print"  /> -->
</form>

<?php
    $class=explode(",",$_POST['class']);
    
?>
<div class="card">
    <div class="card-head">
        <div class="row" style="margin-top:20px;">
            <div class="col-md-6">
                <h3>Roll List</h2>
            </div>
            <div class="col-md-6 text-right">
                <!-- <button style="margin-top:20px;" type="button" class="btn btn-primary" onclick="printDiv()">
                    Print
                </button> -->
                <a target='_blank' class="btn btn-primary" href="pdf_roll_list.php?class=<?php echo $class[0]; ?>">Print</a>
            </div>
        </div>
    </div>
    <div class="card-body" style="margin-top:20px;" id="printArea">
        <div class="row">
            <div class="col-md-6 col-sm-6" style="width:50%;">
                <table class="" style="font-size: 17px; border-collapse: collapse;">
                    <thead>
                        <tr>
                            <th style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                Roll No
                            </th>
                            <th style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                Name
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $stud_details = mysql_query("select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class[0]' and current_class.rollno <= 30 order by current_class.rollno ASC",$con);
                            while($res_stud_details = mysql_fetch_array($stud_details))
                            { 
                        ?>
                        <tr>
                            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                <?php echo $res_stud_details[0]; ?>
                            </td>
                            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                <?php echo $res_stud_details[1]; ?>
                            </td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>

                </table>

            </div>
            <div class="col-md-6 col-sm-6" style="width:50%;">
                <table class="" style="font-size: 17px; border-collapse: collapse;">
                    <thead >
                        <tr>
                            <th style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                Roll No
                            </th>
                            <th style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                Name
                            </th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $stud_details = mysql_query("select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class[0]' and current_class.rollno > 30 order by current_class.rollno ASC",$con);
                            while($res_stud_details = mysql_fetch_array($stud_details))
                            { 
                        ?>
                        <tr>
                            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                <?php echo $res_stud_details[0]; ?>
                            </td>
                            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                <?php echo $res_stud_details[1]; ?>
                            </td>
                        </tr>
                        <?php
                            }
                        ?>
                    </tbody>

                </table>
            </div>

        </div>
        

    </div>

</div>


</body>
</html>

<?php include("includes/footer.php");   ?>
