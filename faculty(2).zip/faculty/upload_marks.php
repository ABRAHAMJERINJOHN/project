<?php
//$con=mysqli_connect("localhost","root","","ritsoft2");
include("connection.php");
//session_start();
//$uname=$_SESSION['fid'];

include("includes/header.php");
include("includes/sidenav.php");



$uname=$_SESSION['fid'];


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Marks</title>
	<script src="jquery-1.9.1.min.js"></script>
	<script>
		function showsub(str)
		{
			var xmlhttp;
			if (window.XMLHttpRequest)
			{
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}

			xmlhttp.open("GET","getsub.php?id="+str,true);
			xmlhttp.send();

			xmlhttp.onreadystatechange=function() 
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("sub").innerHTML=xmlhttp.responseText;

				}
			}
		}
		function get_assess_tool(sub_id){
			console.log(sub_id);
			var xmlhttp;
			if (window.XMLHttpRequest)
			{
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}

			xmlhttp.open("GET","get_assess_tool.php?id="+sub_id,true);
			xmlhttp.send();

			xmlhttp.onreadystatechange=function() 
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("assessment_tool_div").innerHTML=xmlhttp.responseText;

				}
			}
		}
	</script>
	<script>

		$(document).ready(function() {
			$("#sub").change(function () {
				var str = "";
				if ($("#sub option:selected").val()=='')
				{
				//$("#errmsg").html("Please select subject");
				 //$().message("Select subject!");
				 $('#btnshow').attr('disabled', 'disabled');  
			 }
			 else
			 {
			
				 $('#btnshow').removeAttr('disabled');
			 }
		 });
		});

	</script>
	<script type="text/javascript">
		function btn_active(){
			document.getElementById('btnshow').disabled = false;
		}
		function success() {
			if(document.getElementById("textd").value==="") { 
				document.getElementById('button').disabled = true; 
			} else { 
				document.getElementById('button').disabled = false;
			}
		}

	</script>
<script type="text/javascript">
	$(document).ready(function($) {
		$(document).on('click', '#nodatexl', function(event) {
			event.preventDefault(); 
			$this = $('#talbew'); 
			$html =  $this.html() + ""; 
			$('#gooddnowdatafor').find('input').val( $html );
			$('#gooddnowdatafor').submit();

		});
		
	});


</script>

</head>
<div id="page-wrapper">
	<body>
		<div class="map_contact">
			<div class="container">

				<h3 class="tittle">Upload Marks</h3>
				<div class="contact-grids" align="center">

					<div class="col-md-8 contact-grid" style="text-align:center;">
						<form method="post" enctype="multipart/form-data" action="">
							<table align="center" width="700" style="cellspacing:2px;" id="table_select_data">
								<tbody>
									<tr><td> Class</td>  <td>  
										<select name="class" class="form-control" onchange="showsub(this.value)">
											<option>select</option>
											<?php
											$c=mysql_query("select distinct(classid) from subject_allocation where fid='$uname'");

											while($res=mysql_fetch_array($c))
											{
												$res1=mysql_query("select * from class_details where classid='$res[classid]' and active='YES'");
												while($rs=mysql_fetch_array($res1))
												{
													?>
													<option value="<?php echo $rs['classid'].",".$rs['courseid'].",S".$rs['semid'].",".$rs['branch_or_specialisation'];?>">
														<?php echo $rs['courseid'];?>,S<?php echo $rs['semid'];?>,<?php echo $rs['branch_or_specialisation'];?></option>
														<?php
													}
												}
												?>
											</select>
										</td>
									</tr>
												

										<tr>
											<td><h5 style="margin-top: 25px;">Subject</h5></td> 
											<td>
												<div id="sub" style="margin-top: 25px;">
													<select name="sub" class="form-control" onchange="get_assess_tool()">
														<option>select</option>
													</select>
												</div> 
											</td>
										</tr>
										<tr>
											<td><h5 style="margin-top: 25px;">Assessment Tool</h5></td>
											<td>
												<div id="assessment_tool_div" style="margin-top: 25px;">
													<select name="assessment_tool" id="assessment_tool" class="form-control">
														<option>select</option>

													</select>
												</div> 
											</td>
										</tr>
										<tr><td></td><td><input type="submit" name="btnshow" id="btnshow" style="margin-top: 25px;" class="btn btn-primary" value="View" disabled/>  </td></tr> 
										<div style="margin-top: 25px;">
										<!-- <form name="form1" method="post" id="fom_excel_serie_su_suer"> -->
										<div class="" style="text-align:center">
											<style type="text/css">
												.iamloading .resulttable, .imagepare {
													display: none;												
												}
												.iamloading .imagepare, .resulttable {
													display: block;
												}
											</style>
										<div id="outputData" class=" ">
											<div class="imagepare" style="text-align: center;">
												<img style="width: 50px; padding: 3pc 0;" src="../images/loading.gif">
											</div>
											<?php
											include("connection.php");
											if(isset($_POST['btnshow']))
											{
												$assess_tool_id = $_POST['assessment_tool'];
												$sub_id = $_POST['sub'];
												$class_details = explode(",",$_POST['class']);
                                                $class_id = $class_details[0];
												$sem = $class_details[2];
												$dept = $class_details[1];

												$get_tool_details = mysql_query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id'",$con);
												$tool_details_count = mysql_num_rows($get_tool_details);
												if($tool_details_count > 0){
													echo "<script>alert('Already added..')</script>";
													echo "<script>window.location.href='upload_marks.php'</script>";
												}
												else{

													// $assess_tool_id = $_POST['assessment_tool'];
													// $sub_id = $_POST['sub'];
													// $class_details = explode(",",$_POST['class']);
                                                	// $class_id = $class_details[0];
													// $sem = $class_details[2];
													// $dept = $class_details[1];

													$get_assess_tool = mysql_query("Select * from accreditation_assesment_tool where tool_id='$assess_tool_id'",$con);
													while($res_assess_tool = mysql_fetch_array($get_assess_tool) ){
														$asses_tool_name = $res_assess_tool['name'];
														$no_of_questions = $res_assess_tool['no_of_questions'];
													}

													$get_subject_details = mysql_query("Select * from subject_class where subjectid='$sub_id'",$con);
													while($res_subject_details = mysql_fetch_array($get_subject_details) ){
														$subject_title = $res_subject_details['subject_title'];

													}
													?>
												
												<!-- <div id="outputData" class=" "> -->
													<!-- <div class="table-responsive"> -->
														                                        
														<table id="talbew_head" class="table table-hover table-bordered" style="margin-top: 25px;display:none;">	

															<tr>
																<td colspan="11" align="left">
																	<strong><font face="Calibri">I : Details of marks obtained by individual students in <?php echo $asses_tool_name; ?></font></strong>
																</td>
															</tr>

															<tr>
																<td></td>

																<td>
																	<strong>Subject :</strong>
																</td>
																<td>
																	<strong> <?php echo $sub_id; ?> </strong>
																</td>
																<td colspan="3">
																	<strong><?php echo $subject_title; ?></strong>
																</td>
																<td >
																	<strong>Class :</strong>
																</td>
																<td>
																	<strong><?php echo $sem.' '.$dept; ?></strong>
																</td>
																<td>
																	<strong>2021-22</strong>
																</td>

														</tr>
														<tr>
															<td></td>
															<td colspan="10"></td>
														</tr>
														<tr>
															<td></td>
															<td colspan="3" align="right">Question Number -></td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
															?>
																<td><?php echo $questions; ?></td>

															<?php
																}
															?>
															
														</tr>
														<tr>
															<td ></td>
															<td colspan="3" align="right" bgcolor="#d8d8d8">Mapped CO Number -></td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
															?>
																<td bgcolor="#d8d8d8"><input type="text" name="mapped_co<?php echo $questions; ?>" style="width:60px;"></td>

															<?php
																}
															?>
														</tr>
														<tr>
															<td></td>
															<td colspan="3" align="right" bgcolor="#d8d8d8">Max. Mark for the question -></td>
															<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
															?>
																<td bgcolor="#d8d8d8"><input type="text" name="max_mark<?php echo $questions; ?>" style="width:60px;"></td>

															<?php
																}
															?>
														</tr>
                                                        <tr>

                                                	    </tr>
													</table>
														<table id="talbew" class="table table-hover table-bordered" style="display:none;">
										        	    	<tr>
										        	    		<td>rollno</td>
										        	    		<td colspan="3">Name</td>
										        	    		<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
																?>
																<td>Q<?php echo $questions; ?></td>
																<?php
																	}
																?>
																<td>Total</td>
										        	    	</tr>
                                                	        <?php
                                                	            $stud_details = mysql_query("select current_class.rollno,stud_details.name from current_class inner join stud_details on current_class.studid=stud_details.admissionno where classid='$class_id' order by current_class.rollno ASC",$con);
                                                	            while($res_stud_details = mysql_fetch_array($stud_details))
                                                	            { 
                                                	        ?>
                                                	        <tr>
                                                	            <td style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                                	                <?php echo $res_stud_details[0]; ?>
                                                	            </td>
                                                	            <td colspan="3" style="border: 1px solid #dddddd; text-align: left; padding: 4px;">
                                                	                <?php echo $res_stud_details[1]; ?>
                                                	            </td>
																<?php 
																for($questions=1; $questions<=$no_of_questions; $questions++){
																?>
																<td>
																	<!-- <input type="text" id="q<?php //echo $questions; ?>" onkeyup="success()" name="q<?php //echo $questions; ?>" style="width:50px;">                                                                 -->
																</td>
																<?php
																	}
																?>
																<td>
																	<input type="text" id="total" name="total" style="width:50px;">                                                                
																</td>
                                                	        </tr>
                                                	        <?php
                                                	            }
                                                	        ?>
										        	    </table>
														<input type="hidden" name="a_tool_id" value="<?php echo $assess_tool_id; ?>">
														<input type="hidden" name="no_of_qstn" value="<?php echo $no_of_questions; ?>">
													<!-- </div> -->
												</div>
											</body>
										</div>
										<!-- <div class="col-md-8 contact-grid" style="text-align:center ; margin-bottom: 1pc; margin-top:15px;">
											<input type="submit" class="btn btn-primary" name="submit_details"  value="Submit"/>   
										</div> -->
									</form>
								</div>
							</div>
						<!-- <button class="btn btn-primary" style="margin-top:15px;margin-left:60px;"id="nodatexl">excel</button> -->
						<div class="row" style="margin-bottom:10px;" style="">
							<div class="col-md-offset-3 col-sm-2 text-center">
								<button class="btn btn-primary" style="margin-top:15px;float:right;"id="nodatexl">download excel template</button>
							</div>
							<div class="col-md-offset-2 col-sm-2 text-center">
								<button class="btn btn-primary select_excel"id="select_excel_button" style="margin-top:15px; float:left;">input from excel</button>
							</div>
						</div>

						<form method="post" action="form2_excel.php"   id="fom_excel_serie_su" enctype="multipart/form-data" >
										
							<input type="file" name="selected_excel" id="selected_excel" accept=".csv, application/vnd.openxmlformats-officedocument.spreadsheetml.sheet, application/vnd.ms-excel, .xlsx, .xls" style="display: none;">

							<input type="hidden" value="<?php echo $class_id; ?>" name="class_id"/>
							<input type="hidden" value="<?php echo $sub_id; ?>" name="sub_code"/>
							<input type="hidden" value="<?php echo $assess_tool_id; ?>" name="ass_tool_id"/>
							<input type="hidden" value="<?php echo $sem; ?>" name="sem"/>
							<input type="hidden" value="<?php echo $dept; ?>" name="dept"/>


							<input type="submit"  id="fom_excel_serie" style="display: none;" value="Upload Excel" name="submit">
						</form>

						<form id="gooddnowdatafor" action="html_to_xl.php" method="post" target="_blank" style="display: none;">
							<input type="hidden" name="html">
						</form>
				</div>

			</div>
		</div>

<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<?php
}
}
?>
<?php
	// code for save data into assessment tool details
	if(isset($_POST['submit_details'])){
		$a_tool_id = $_POST['a_tool_id'];
		$no_of_qstn = $_POST['no_of_qstn'];
		$classId = $_POST['classId'];
		echo "<script> console.log('assess_tool_id is '+$a_tool_id)</script>";
		echo "<script> console.log('no of qstn is '+$no_of_qstn)</script>";
		echo "<script> console.log('class id is '+$classId)</script>";
		$status = '1';
		for($question=1;$question<=$no_of_qstn;$question++)
    	{
			$mapped_co = $_POST['mapped_cos'.$question];
			$max_mark = $_POST['max_marks'.$question];
		
			$sql_tool_details = mysql_query( "insert into accreditation_assesment_tool_details(tool_id,question_no,mapped_co,max_mark,status)VALUES ('$a_tool_id','$question','$mapped_co','$max_mark','$status')",$con);
		}
		$get_stud_details = mysql_query("select studid from current_class where classid='$classId' order by rollno ASC",$con);
        while($res_stud = mysql_fetch_array($get_stud_details))
        {
			$mark_string = '';
			$admission_no = $res_stud[0];
			for($question=1;$question<=$no_of_qstn;$question++){
				$qstn_string = 'q'.$question;
				$mark_field = $admission_no.$qstn_string;
				$marks = $_POST[$mark_field];
				if($mark_string == ''){
					if($marks == ''){
						$mark_string = ',';
					}
					else{
						$mark_string = $marks.',';
					}
				}
				else{
					if($marks == ''){
						if($question == 2){
							$mark_string = $mark_string.'';
						}
						else{
							$mark_string = $mark_string.',';
						}
					}
					else{
						if($question == 2){
							$mark_string = $mark_string.$marks;
						}
						else{
							$mark_string = $mark_string.','.$marks;
						}
					}
				}

			}

			$sql_tool_data = mysql_query( "insert into accreditation_assesment_data(tool_id,admission_no,marks,status)VALUES ('$a_tool_id','$admission_no','$mark_string','$status')",$con);

		}
		if($sql_tool_details && $sql_tool_data){
			echo "<script>alert('Succesfully added')</script>";
			echo "<script>window.location.href='upload_marks.php'</script>";
		}
		else{
			echo "<script>alert('Failed to add')</script>";
			echo "<script>window.location.href='upload_marks.php'</script>";
		}
	}

?>
<script type="text/javascript">

$(document).ready(function($) {
	console.log('ready');
	$('#on_top_me_now').remove();

	$('.downlad_excel').click(function(event) {
		
		window.open('excel_template.php?action=template-mark&type=excel','_blank' );

	});
	$('.select_excel').click(function(event) {
		event.preventDefault();
		console.log('now excel time ');
		$('#selected_excel').click();
	});
	$('#selected_excel').change(function(e) { 
		e.preventDefault();     
		$("#fom_excel_serie_su").submit();
	});
	$("#fom_excel_serie_su").submit(function(e) {
		e.preventDefault();
		//new added
		$('#talbew_head').css("display", "none");
		$('#talbew').css("display", "none");
		$('#table_select_data').css("display", "none");
		$('#select_excel_button').css("display", "none");
		$('#nodatexl').css("display", "none");
		//end    
		var formData = new FormData(this);
		$('#outputData').addClass('iamloading');
		$.ajax({
			url: 'form2_excel.php',
			type: 'POST',
			data: formData,
			success: function (data) {
				console.log(data);
				$('#outputData').removeClass('iamloading'); 
				$('#outputData').html(data);

				//document.getElementById('button').disabled = false;
				
			},
			cache: false,
			contentType: false,
			processData: false
		});
	});

});

</script>
</body>

</html>

<?php

include("includes/footer.php");
?>