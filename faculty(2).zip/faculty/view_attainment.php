<?php
//$con=mysqli_connect("localhost","root","","ritsoft2");
include("connection.php");
//session_start();
//$uname=$_SESSION['fid'];

include("includes/header.php");
include("includes/sidenav.php");



$uname=$_SESSION['fid'];


?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>Marks</title>
	<script src="jquery-1.9.1.min.js"></script>
	<script>
		function showsub(str)
		{
			var xmlhttp;
			if (window.XMLHttpRequest)
			{
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}

			xmlhttp.open("GET","getsub.php?id="+str,true);
			xmlhttp.send();

			xmlhttp.onreadystatechange=function() 
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("sub").innerHTML=xmlhttp.responseText;

				}
			}
		}
		function get_assess_tool(sub_id){
			console.log(sub_id);
			var xmlhttp;
			if (window.XMLHttpRequest)
			{
				xmlhttp=new XMLHttpRequest();
			}
			else
			{
				xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
			}

			xmlhttp.open("GET","get_assess_tool.php?id="+sub_id,true);
			xmlhttp.send();

			xmlhttp.onreadystatechange=function() 
			{
				if(xmlhttp.readyState==4 && xmlhttp.status==200)
				{
					document.getElementById("assessment_tool_div").innerHTML=xmlhttp.responseText;

				}
			}
		}
	</script>
	<script>

		$(document).ready(function() {
			$("#sub").change(function () {
				var str = "";
				if ($("#sub option:selected").val()=='')
				{
				//$("#errmsg").html("Please select subject");
				 //$().message("Select subject!");
				 $('#btnshow').attr('disabled', 'disabled');  
			 }
			 else
			 {
			
				 $('#btnshow').removeAttr('disabled');
			 }
		 });
		});

	</script>
	<script type="text/javascript">
		function btn_active(){
			document.getElementById('btnshow').disabled = false;
		}
		function success() {
			if(document.getElementById("textd").value==="") { 
				document.getElementById('button').disabled = true; 
			} else { 
				document.getElementById('button').disabled = false;
			}
		}

	</script>
<script type="text/javascript">
	$(document).ready(function($) {
		$(document).on('click', '#nodatexl', function(event) {
			event.preventDefault(); 
			$this = $('#talbew'); 
			$html =  $this.html() + ""; 
			$('#gooddnowdatafor').find('input').val( $html );
			$('#gooddnowdatafor').submit();

		});
		
	});


</script>

</head>
<div id="page-wrapper">
	<body>
		<div class="map_contact">
			<div class="container">

				<h3 class="tittle">View Attainment</h3>
				<div class="contact-grids" align="center">

					<div class="col-md-8 contact-grid" style="text-align:center;">
						<form method="post" enctype="multipart/form-data" action="">
							<table align="center" width="700" style="cellspacing:2px;" id="table_select_data">
								<tbody>
									<tr><td> Class</td>  <td>  
										<select name="class" class="form-control" onchange="showsub(this.value)">
											<option>select</option>
											<?php
											$c=mysql_query("select distinct(classid) from subject_allocation where fid='$uname'");

											while($res=mysql_fetch_array($c))
											{
												$res1=mysql_query("select * from class_details where classid='$res[classid]' and active='YES'");
												while($rs=mysql_fetch_array($res1))
												{
													?>
													<option value="<?php echo $rs['classid'].",".$rs['courseid'].",S".$rs['semid'].",".$rs['branch_or_specialisation'];?>">
														<?php echo $rs['courseid'];?>,S<?php echo $rs['semid'];?>,<?php echo $rs['branch_or_specialisation'];?></option>
														<?php
													}
												}
												?>
											</select>
										</td>
									</tr>
												

										<tr>
											<td><h5 style="margin-top: 25px;">Subject</h5></td> 
											<td>
												<div id="sub" style="margin-top: 25px;">
													<select name="sub" class="form-control" onchange="get_assess_tool()">
														<option>select</option>
													</select>
												</div> 
											</td>
										</tr>
										<tr>
											<td><h5 style="margin-top: 25px;">Assessment Tool</h5></td>
											<td>
												<div id="assessment_tool_div" style="margin-top: 25px;">
													<select name="assessment_tool" id="assessment_tool" class="form-control">
														<option>select</option>

													</select>
												</div> 
											</td>
										</tr>
										<tr><td></td><td><input type="submit" name="btnshow" id="btnshow" style="margin-top: 25px;" class="btn btn-primary" value="View"/>  </td></tr> 
										<div style="margin-top: 25px;">
										<!-- <form name="form1" method="post" id="fom_excel_serie_su_suer"> -->
										<div class="" style="text-align:center">
											<style type="text/css">
												.iamloading .resulttable, .imagepare {
													display: none;												
												}
												.iamloading .imagepare, .resulttable {
													display: block;
												}
											</style>
										<div id="outputData" class=" ">
											<div class="imagepare" style="text-align: center;">
												<img style="width: 50px; padding: 3pc 0;" src="../images/loading.gif">
											</div>
											<?php
											include("connection.php");
											if(isset($_POST['btnshow']))
											{
												$assess_tool_id = $_POST['assessment_tool'];
												$sub_id = $_POST['sub'];
												$class_details = explode(",",$_POST['class']);
                                                $class_id = $class_details[0];
												$sem = $class_details[2];
												$dept = $class_details[1];

												// $get_tool_details = mysql_query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id'",$con);
												// $tool_details_count = mysql_num_rows($get_tool_details);
												// if($tool_details_count > 0){
												// 	echo "<script>alert('Already added..')</script>";
												// 	echo "<script>window.location.href='upload_marks.php'</script>";
												// }
												// else{

													$get_assess_tool = mysql_query("Select * from accreditation_assesment_tool where tool_id='$assess_tool_id'",$con);
													while($res_assess_tool = mysql_fetch_array($get_assess_tool) ){
														$asses_tool_name = $res_assess_tool['name'];
														$no_of_questions = $res_assess_tool['no_of_questions'];
														$target = $res_assess_tool['target_percentage'];
													}

													$get_subject_details = mysql_query("Select * from subject_class where subjectid='$sub_id'",$con);
													while($res_subject_details = mysql_fetch_array($get_subject_details) ){
														$subject_title = $res_subject_details['subject_title'];

													}

													$max_mark_array = array();
													for($questions=1; $questions<=$no_of_questions; $questions++){
                                                        $get_assess_tool_details = mysql_query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'",$con);
													    while($res_assess_tool_details = mysql_fetch_array($get_assess_tool_details) ){
                                                            $max_mark_array[$questions] = $res_assess_tool_details[4];
                                                        }
                                                    }
													$mapped_co_array = array();
													for($questions=1; $questions<=$no_of_questions; $questions++){
                                                        $get_assess_tool_details = mysql_query("Select * from accreditation_assesment_tool_details where tool_id='$assess_tool_id' and question_no = '$questions'",$con);
													    while($res_assess_tool_details = mysql_fetch_array($get_assess_tool_details) ){
                                                            $mapped_co_array[$questions] = $res_assess_tool_details[3];
                                                        }
                                                    }
                                                    $count_old = 0;
                                                    $average_mark_array = array();
                                                    $average_percentage_array = array();
                                                    $student_above_target_array = array();
                                                    $student_attend_array = array();
                                                    $above_target_percentage_array = array();
                                                    $sum_array = array();
                                                    $target_value = array();
                                                    $attainment_level_array = array();
                                                    $co_count_array = array();
                                                    $attainment_sum_array = array();
                                                    
                                                    // for($i=0; $i<$no_of_questions; $i++){
                                                    //     $sum_array[$i] = 0;
                                                    // } 
                                                    $get_stud_details = mysql_query("select studid from current_class where classid='$class_id' order by rollno ASC",$con);
                                                    $students_count = mysql_num_rows($get_stud_details);
                                                    while($res_stud = mysql_fetch_array($get_stud_details))
                                                    {
                                                        $admission_no = $res_stud[0];
                                                        
                                                        // foreach($admission_no as $admissionNo){
                                                            $get_assess_data = mysql_query("select marks from accreditation_assesment_data where admission_no='$admission_no' and tool_id='$assess_tool_id' ",$con);
                                                            while($res_assess_data = mysql_fetch_array($get_assess_data)){
                                                                $marks = explode(",",$res_assess_data[0]);
                                                                // echo "<script>console.log('marks '+$marks[0])</script>";
                                                                for($i=0,$j=1; $i<$no_of_questions,$j<=$no_of_questions; $i++,$j++){
                                                                    
                                                                    $sum_old = $sum_array[$j];
                                                                    $sum_array[$j] = $marks[$i] + $sum_old;
                                                                    
                                                                    $target_value[$j] = ($target/100) * $max_mark_array[$j];
                                                                    // echo "<script>console.log('target_value for '+$j+' is'+$target_value[$j])</script>";


                                                                    if($marks[$i] >= $target_value[$j]){

                                                                        $student_above_target_array[$j] = $student_above_target_array[$j] + 1;
                                                                        // echo "<script>console.log('student_above_target_array of for '+$j+' is '+$student_above_target_array[$j])</script>";
                                                                    }
                                                                    if($marks[$i] != ''){

                                                                        $student_attend_array[$j] = $student_attend_array[$j] + 1;
                                                                    }
                                                                        
                                                                }
                                                            }

                                                        // }
                                                    }
                                                    for($j=1; $j<=$no_of_questions; $j++){

                                                        $average_mark_array[$j] = $sum_array[$j]/$student_attend_array[$j];
                                                        $average_percentage_array[$j] = ($average_mark_array[$j]/$max_mark_array[$j])*100;

                                                    }
                                                    for($j=1; $j<=$no_of_questions; $j++){

                                                        $above_target_percentage_array[$j] = ($student_above_target_array[$j]/$student_attend_array[$j])*100;

                                                    }
													$get_co = mysql_query("Select * from course_outcome where subject_id='$sub_id'",$con);
													while($res_co = mysql_fetch_array($get_co)){
														$co_id = $res_co[0];
														$attainment_sum_array[$co_id] = 0;
													}
													
													
                                                    
											?>
												
												<!-- <div id="outputData" class=" "> -->
													<!-- <div class="table-responsive"> -->
														                                        
														<table id="talbew_head" class="table table-hover table-bordered" style="margin-top: 25px; margin-bottom:25px;">	
                                                            <tr>
														    	<th>
                                                                    <strong>Question Number</strong>
                                                                </th>
														    	<?php 
														    		for($questions=1; $questions<=$no_of_questions; $questions++){
														    	?>
														    		<th><?php echo $questions; ?></th>

														    	<?php
														    		}
														    	?>
    
														    </tr>
                                                            <tr>
														    	<th>
                                                                    <strong>Maximum Mark</strong>
                                                                </th>
                                                                <?php
                                                                    foreach($max_mark_array as $max_mark_arr){
                                                                        echo "<th>$max_mark_arr</th>";
                                                                    }
                                                                ?>
														    </tr>
                                                            <tr>
                                                                <td align="left">
																	Average
																</td>
                                                                <?php
                                                                        foreach($average_mark_array as $avg_arr){
                                                                            echo "<td>".round($avg_arr,2)."</td>";
                                                                        }
                                                                ?>
                                                            </tr>
															
															<tr>
																<td  align="left">
																	Average Percentage
																</td>
															
                                                                <?php
                                                                        foreach($average_percentage_array as $avg_perc){
                                                                            echo "<td>".round($avg_perc,2)."</td>";
                                                                        }
                                                                ?>
														    </tr>
															<tr>
																<td  align="left">
																	No of Students attained above <?php echo $target ?>%
																</td>
															
                                                                <?php 
														    		for($questions=1; $questions<=$no_of_questions; $questions++){
																		if($student_above_target_array[$questions]>0){
														    	?>
														    		<td><?php echo $student_above_target_array[$questions]; ?></td>

														    	<?php
														    		}
																	else{
														    	?>
																	<td>0</td>

														    	<?php
														    		}
																}
														    	?>
														    </tr>
															<tr>
																<td  align="left">
																	No of students attempted
																</td>
															
                                                                <?php 
															        for($questions=1; $questions<=$no_of_questions; $questions++){
															    ?>
															        <td><?php echo $student_attend_array[$questions]; ?></td>
															    <?php
															        }
															    ?>
														    </tr>
															<tr>
																<td  align="left">
																	Percentage of students who obtained the targetted percentage of marks
																</td>
															
                                                                <?php 
															        for($questions=1; $questions<=$no_of_questions; $questions++){
															    ?>
															        <td><?php echo round($above_target_percentage_array[$questions],2); ?></td>
															    <?php
															        }
															    ?>
														    </tr>
															<tr>
																<th>
																	<strong>CO attainment level</strong>
																</th>
															
                                                                <?php
																	$get_attainment_level = mysql_query("select * from accreditation_co_level", $con);
																	while($res_attainment_level = mysql_fetch_array($get_attainment_level)){
															        	for($questions=1; $questions<=$no_of_questions; $questions++){
																			$above_trgt_percentage = round($above_target_percentage_array[$questions],2);
																			if( $above_trgt_percentage > $res_attainment_level[3]){
																				echo "<th>3</th>";
																				$attainment_level_array[$questions]='3';
																			}
																			elseif( $above_trgt_percentage < $res_attainment_level[3] && $above_trgt_percentage > $res_attainment_level[2]){
																				echo "<th>2</th>";
																				$attainment_level_array[$questions]='2';
																			}
																			elseif( $above_trgt_percentage < $res_attainment_level[2] && $above_trgt_percentage > $res_attainment_level[1]){
																				echo "<th>1</th>";
																				$attainment_level_array[$questions]='1';
																			}
																			elseif( $above_trgt_percentage < $res_attainment_level[1]){
																				echo "<th>0</th>";
																				$attainment_level_array[$questions]='0';
																			}
																
																		}
															        }
															    ?>
														    </tr>
														
														
													    </table>
														<h4>Average CO Attainment</h4>
														<table class="table table-hover table-bordered" style="margin-top: 25px; margin-bottom:25px;">
															<tr>
																<?php
																 $get_co = mysql_query("Select * from course_outcome where subject_id='$sub_id'",$con);
																 while($res_co = mysql_fetch_array($get_co)){
																	 echo "<th>$res_co[2]</th>";
																 }
																?>
															</tr>
															<tr>
															<?php
																for($j=1; $j<=$no_of_questions; $j++){
																	$get_co = mysql_query("Select * from course_outcome where subject_id='$sub_id'",$con);
																	while($res_co = mysql_fetch_array($get_co)){
																		$co_id = $res_co[0];
																		if($mapped_co_array[$j] == $co_id){
																			 $co_count_array[$co_id] = $co_count_array[$co_id] + 1;
																			 $attainment_sum_array[$co_id] = $attainment_sum_array[$co_id] + $attainment_level_array[$j];
																			 echo "<script>console.log('co id is '+$co_id+' co count is '+$co_count_array[$co_id])</script>";
																			 echo "<script>console.log('co id is '+$co_id+' attainment sum '+$attainment_sum_array[$co_id])</script>";
																		}
																 	}
																}
																$get_co = mysql_query("Select * from course_outcome where subject_id='$sub_id'",$con);
																while($res_co = mysql_fetch_array($get_co)){
																	$co_id = $res_co[0];
																	$average_co_attainment = $attainment_sum_array[$co_id]/$co_count_array[$co_id];
																	echo "<th>$average_co_attainment</th>";
																}

															?>
															</tr>
														</table>
														
													<!-- </div> -->
												</div>
											</body>
										</div>
										<!-- <div class="col-md-8 contact-grid" style="text-align:center ; margin-bottom: 1pc; margin-top:15px;">
											<input type="submit" class="btn btn-primary" name="submit_details"  value="Submit"/>   
										</div> -->
									</form>
								</div>
							</div>
						<!-- <button class="btn btn-primary" style="margin-top:15px;margin-left:60px;"id="nodatexl">excel</button> -->
						
				</div>

			</div>
		</div>

<link href="//cdnjs.cloudflare.com/ajax/libs/x-editable/1.5.0/bootstrap3-editable/css/bootstrap-editable.css" rel="stylesheet"/>
<?php
}
// }
?>


</body>

</html>

<?php

include("includes/footer.php");
?>